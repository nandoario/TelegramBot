# pip install python-telegram-bot
from telegram.ext import *

import keys

print('Starting up bot...')


# Lets us use the /start command
def start_command(update, context):
    update.message.reply_text('Hallo teman-teman Kelas 3BDG-P1 ! Aku Rocky😉\n\nSilahkan klik /help untuk melihat beberapa layanan yang saat ini tersedia untuk kalian ☺️ ')


# Lets us use the /help command
def help_command(update, context):
    update.message.reply_text('1.Silahkan klik /compro untuk melihat seluruh ulasan materi compro pada semester ini\n\n2.Silahkan klik /tutor untuk melihat beberapa turorial seperti membuat bot telegram, web scraping, dll\n\n3.Silahkan klik /baca untuk rekomendasi bahan bacaan')


# Lets us use the /custom command
def custom_command(update, context):
    update.message.reply_text('Fitur ini belum memiliki layanan, Jika ada request layanan tertentu silahkan kirim ke email ke keponakan elon musk 🤠😎 \n>> nandoario99@gmail.com << \n\nTerima Kasih :)')


def handle_response(text) -> str:
    # Create your own response logic

    if '/compro' in text:
        return '1. Manipulasi String ~klik /a untuk ulasan\n\n2. Tipe Data Casting ~klik /b untuk ulasan\n\n3. Modul dan Paket ~klik /c untuk ulasan\n\n4.Modul dan Paket Lanjutan ~klik /d untuk ulasan\n\n5. Pengenalan dan Konsep OOP ~klik /e untuk ulasan\n\n6. Brainstorming ~klik /f untuk ulasan\n\n7. Kelas dan Objek ~klik /g untuk ulasan\n\n8. Inheritance ~klik /h untuk ulasan\n\n9. Telegram BOT ~klik /i untuk ulasan\n\n10. Overriding ~klik /j untuk ulasan\n\n11. Access Modifiers ~klik /k untuk ulasan\n\n12. Web Scraping ~klik /l untuk ulasan\n\n13. Library Googletrans ~klik /m untuk ulasan'

    if '/tutor' in text:
        return '1. klik /telgramBot untuk Tutorial BOT telegram sederhana dengan Python\n\n2. klik /web untuk Tutorial Web Scraping dengan Python\n\n3. klik /trans untuk Tutorial Menterjemahkan Bahasa dengan Python\n\n4. klik /remot untuk informasi Tutorial Program simulator AC dengan Python\n\n5. klik /oke untuk mendapatkan jokes bapack2\n\nrocky minta maap yah untuk saat ini hanya tersedia beberapa pilihan... macihh😇'
    
    if '/baca' in text:
        return 'Silahkan Klik Link berikut untuk membaca beragam pengetahuan seputar teknologi dan bisnis di era sekarang \n> https://rockerwebsite.id/blog.php <'

    if '/a' in text:
        return 'Manipulasi String adalah bagian penting dari pemrograman karena itu membantu untuk memproses data yang datang dalam bentuk jenis non - numerik seperti nama , alamat , jeniskelamin , kota , judul buku dan banyak lagi.\n\nJawaban Selengkapnya silahkan klik link berikut : https://jagongoding.com/python/menengah/manipulasi-string-part-1/'

    if '/b' in text:
        return 'Apa itu Konversi Tipe Data?\n\nKonversi tipe data adalah teknik mengubah nilai yang awalnya dari tipe data a,menjadi tipe data b. Terdapat 2 cara dalam mengkonversi tipe data:\n\nKonversi secara implisit (otomatis) dan Konversi secara eksplisit (manual)\n\nKenapa Data Butuh Dikonversi?\n\nJawabannya adalah: tidak semua data itu valid dan tidak semua data itu bisa kita oleh sesuai kebutuhan.\n\nJawaban Selengkapnya silahkan klik link berikut : https://jagongoding.com/python/menengah/tipe-data-casting/'
    
    if '/c' in text:
        return '1. Module Python\n\nModule pada Python adalah sebuah file yang berisikan sekumpulan kode fungsi, class dan variabel yang disimpan dalam satu file berekstensi .py dan dapat dieksekusi oleh interpreter Python. Nama dari module .py merupakan nama nama dari file itu sendiri. Misalkan kita memiliki file bernama "dqlab.py", maka kita telah membuat sebuah module bernama "dqlab. Dan module sendiri bisa memiliki berbagai macam isi, baik itu fungsi, class, maupun variabel.\n\n\n2. Package pada Python\n\nPaket pada Python adalah sekumpulan module python yang berada dalam sebuah folder serta memiliki satu module constructor (__init__.py). Paket ini merupakan sebuah cara untuk mengelola dan mengorganisir module-module python dalam bentuk direktori, memungkinkan sebuah module untuk diakses menggunakan "namespace" dan dot lokasi. Untuk apa module constructor (__init__.py) pada sebuah package? File constructor berfungsi untuk memberi tahu python interpreter bahwa folder tersebut adalah sebuah package. Jadi, setiap direktori atau folder yang berisi module constructor __init__.py akan diperilakukan sebagai pakcage.\n\nJawaban Selengkapnya silahkan klik link berikut :https://www.dqlab.id/library-python-kenali-perbedaan-module-package-dan-library-pada-python'

    if '/d' in text:
        return 'Dalam materi ini, kita akan membahas hal-hal berkaitan dengan modul dan paket pada python, apa manfaatnya dan bagaimana cara mengimpelementasikannya.\n\nJawaban Selengkapnya silahkan klik link berikut :https://jagongoding.com/python/menengah/modul-dan-paket/'


    if '/e' in text:
        return 'Dalam proses penulisan program, kita biasanya akan terlibat sebuah “diskusi” tentang kapan struktur sebuah kode dikatakan bagus. Apakah yang menganut konsep Object Oriented Programming (OOP), atau yang mengikuti konsep prosedural, atau bahkan konsep fungsional?\n\nMungkin bagi pemula, kita belum pernah menulis kode program yang cukup besar sampai ribuan baris kode dan puluhan bahkan ratusan file.\n\nKalau kita sudah pernah melakukan hal itu –entah projek akhir sekolah atau projek akhir kuliah, kita baru akan sadar bahwa ternyata semua hal bisa menjadi sangat rumit jika kita tidak mengadopsi pendekatan yang baik.\n\nJawaban Selengkapnya silahkan klik link berikut :https://jagongoding.com/python/menengah/oop/konsep/'    


    if '/f' in text:
        return 'Brainstorming adalah suatu metode yang memanfaatkan teknik kreativitas dalam mencari penyelesaian dari suatu masalah tertentu dengan mengumpulkan gagasan secara spontan dari anggota kelompok.'

    if '/g' in text:
        return 'Semua Hal Pada Python Adalah Objek\nSebelumnya, kita perlu tahu dulu bahwa sesuatu tidaklah dikatakan objek kecuali jika memiliki atribut atau perilaku.\nAtribut adalah semacam identitas atau variabel dari suatu objek, sedangkan perilaku adalah “kemampuan” atau fitur dari objek tersebut.\nKita juga bisa definisikan dalam bentuk yang lebih sederhana lagi, yaitu: objek adalah sebuah gabungan dari kumpulan variabel (dinamakan atribut) dan kumpulan fungsi (dinamakan perilaku)\n\nDan atas definisi itu, maka bisa dikatakan bahwa semua hal di dalam python adalah sebuah objek \n\nBahkan Sebuah Fungsi Pun Adalah Objek\nKalau kita teliti lebih jauh lagi, setiap fungsi pada python memiliki atribut __doc__ yang merupakan bukti bahwa fungsi sekalipun adalah sebuah objek dalam python.\n\nJawaban Selengkapnya silahkan klik link berikut :https://jagongoding.com/python/menengah/oop/kelas-dan-objek/'
    
    if '/h' in text:
        return 'Bagaimana konsep pewarisan bekerja?\n\nKonsep pewarisan adalah konsep di mana sebuah kelas atau objek mewariskan sifat dan perilaku kepada kelas lainnya.\nKelas yang menjadi “pemberi waris” dinamakan kelas induk atau kelas basis\n\nSedangkan kelas yang menjadi “ahli waris” dinamakan sebagai kelas turunan.\n\nSifat Pewarisan\nSecara umum, kelas turunan akan selalu memiliki sifat dan perilaku yang sama dengan kelas induknya: mulai dari atribut sampai fungsi-fungsinya.\n\nAkan tetapi tidak sebaliknya, belum tentu kelas induk memiliki semua atribut dan sifat dari kelas-kelas turunannya.\n\n\nJawaban Selengkapnya silahkan klik link berikut :https://jagongoding.com/python/menengah/oop/pewarisan/'

    if '/i' in text:
        return 'Silahkan klik link berikut :https://www.codementor.io/@karandeepbatra/part-1-how-to-create-a-telegram-bot-in-python-in-under-10-minutes-19yfdv4wrq'

    if '/j' in text:
        return 'Pengertian Overriding\n\nApa itu overriding dalam konsep pemrograman berorientasi objek?\nDi dalam semua bahasa pemrograman yang berbasis objek, teknik overriding adalah fitur yang memungkinkan kita untuk mengimplementasikan “ulang” fungsi/method pada sebuah child class atau kelas turunan yang sebenarnya fungsi tersebut telah didefinisikan di dalam parent class atau kelas induk\n\n\nJawaban Selengkapnya silahkan klik link berikut :https://jagongoding.com/python/menengah/oop/overriding/'    

    if '/k' in text:
        return 'Access Modifiers adalah sebuah konsep di dalam pemrograman berorientasi objek di mana kita bisa mengatur hak akses suatu atribut dan fungsi pada sebuah class. Konsep ini juga biasa disebut sebagai enkapsulasi, di mana kita akan mendefinisikan mana atribut atau fungsi yang boleh diakses secara terbuka, mana yang bisa diakses secara terbatas, atau mana yang hanya bisa diakses oleh internal kelas alias privat.\n\n\nJawaban Selengkapnya silahkan klik link berikut :https://jagongoding.com/python/menengah/oop/access-modifiers/'

    if '/l' in text:
        return 'Selengkapnya silahkan klik link berikut :https://ngodingdata.com/tutorial-web-scraping-dengan-beautifulsoup-di-python-part-3/'

    if '/m' in text:
        return 'Selengkapnya silahkan klik link berikut :https://kotakode.com/blogs/10708/Mengenal-Googletrans%2C-modul-Google-Translate-untuk-Python'

    if '/telgramBot' in text:
        return 'Untuk Tutorial membuat telegram BOT silahkan kunjungi Link berikut :'

    if '/web' in text:
        return 'Untuk Tutorial web scraping silahkan kunjungi Link berikut : https://ngodingdata.com/tutorial-web-scraping-dengan-beautifulsoup-di-python-part-1/'

    if '/trans' in text:
        return 'Untuk Tutorial membuat program googletrans silahkan kunjungi Link berikut :https://idkuu.com/cara-menggunakan-translate-pada-python'

    if '/remot' in text:
        return 'Untuk Tutorial membuat program simulator remote AC silahkan kunjungi Link berikut :https://www.anbidev.com/python-ac-remote/'

    if '/oke' in text:
        return 'Sabun apa yang paling genit?\nJawab: Sabun colek\n\nKenapa kalo lagi mikir orang suka megang jidatnya?\n-Ya iyalah, masa megang jidat orang lain!\n\nKenapa kucing selalu menyembunyikan kotorannya dalam pasir?\n-Karena takut diambil kamu!\n\nSeekor kaki seribu mempunyai 1.000 kaki, suatu hari kakinya copot satu. Tinggal berapa kakinya?\n-Kan kayak di lagu Gugur bunga, “Gugur satu tumbuh seribu.”\n\nSepeda apa yang tidak bisa dicat?\n-Sepeda hilang!\n\nBenda apa yang baru dibeli langsung dibuang?\n-Peti mati.\n\n'

    if 'Apa kabar?' in text:
        return 'alhamdulillah rocky cok, lu apa kabar?'

    if 'Apa kabar' in text:
        return 'alhamdulillah rocky cok, lu apa kabar?'

    if 'Hallo' in text:
        return 'halloooo jugaaaaaaaaa rocky ciap membantu nich!'

    if 'hallo' in text:
        return 'halloooo jugaaaaaaaaa rocky ciap membantu nich!'

    if 'hai' in text:
        return 'y'
    
    if 'Terima Kasih !' in text:
        return 'Berterima kasihlah kepada Pak Galih, sebab beliau yang memberikan materi yang rumit ini, namun dengan cara mengajar beliau, materi yang rumit ini menjadi sangat mudah untuk di cerna. Thanks a lot Pak! Sukses selalu, Doa rocky yang asik asik menyertaimu :)\n\n\nPak Galih = ⭐⭐⭐⭐⭐'

    if 'terima kasih' in text:
        return 'Berterima kasihlah kepada Pak Galih, sebab beliau yang memberikan materi yang rumit ini, namun dengan cara mengajar beliau, materi yang rumit ini menjadi sangat mudah untuk di cerna atau dengan kata lain EZ Mannnn. \n\nThanks a lot Pak Galih! Sukses selalu, Doa rocky yang asik asik menyertaimu :)\n\n\nPak Galih = ⭐⭐⭐⭐⭐'

    if 'thank you' in text:
        return 'Berterima kasihlah kepada Pak Galih, sebab beliau yang memberikan materi yang rumit ini, namun dengan cara mengajar beliau, materi yang rumit ini menjadi sangat mudah untuk di cerna. Thanks a lot Pak! Sukses selalu, Doa rocky yang asik asik menyertaimu :)\n\n\nPak Galih = ⭐⭐⭐⭐⭐'
    
    if 'Thank you' in text:
        return 'Berterima kasihlah kepada Pak Galih, sebab beliau yang memberikan materi yang rumit ini, namun dengan cara mengajar beliau, materi yang rumit ini menjadi sangat mudah untuk di cerna. Thanks a lot Pak! Sukses selalu, Doa rocky yang asik asik menyertaimu :)\n\n\nPak Galih = ⭐⭐⭐⭐⭐'   

    return 'maap, rocky belum diprogram untuk apa yang kamu ketik tau... 🥺\nAtau coba klik /help untuk back to layananku deh...🤗'


def handle_message(update, context):
    # Get basic info of the incoming message
    message_type = update.message.chat.type
    text = str(update.message.text).lower()
    response = ''

    # Print a log for debugging
    print(f'User ({update.message.chat.id}) says: "{text}" in: {message_type}')

    # React to group messages only if users mention the bot directly
    if message_type == 'group':
        # Replace with your bot username
        if '@mrrockerbot' in text:
            new_text = text.replace('@mrrockerbot', '').strip()
            response = handle_response(new_text)
    else:
        response = handle_response(text)

    # Reply normal if the message is in private
    update.message.reply_text(response)


# Log errors
def error(update, context):
    print(f'Update {update} caused error {context.error}')


# Run the program
if __name__ == '__main__':
    updater = Updater(keys.token, use_context=True)
    dp = updater.dispatcher

    # Commands
    dp.add_handler(CommandHandler('start', start_command))
    dp.add_handler(CommandHandler('help', help_command))
    dp.add_handler(CommandHandler('custom', custom_command))

    # Messages
    dp.add_handler(MessageHandler(Filters.text, handle_message))

    # Log all errors
    dp.add_error_handler(error)

    # Run the bot
    updater.start_polling(1.0)
    updater.idle()
